<?php
if(is_admin()){
	require NEWSBLOGGER_CHILD_TEMPLATE_DIR . '/admin/inc/class-spicethemes-about-page.php';
}