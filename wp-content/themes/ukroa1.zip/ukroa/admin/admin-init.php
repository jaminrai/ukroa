<?php
if(is_admin()){
	require NEWSCRUNCH_TEMPLATE_DIR . '/admin/inc/class-spicethemes-about-page.php';
}