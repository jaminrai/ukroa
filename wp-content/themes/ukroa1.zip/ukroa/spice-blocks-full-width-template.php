<?php
/**
 * Template Name: Spice Blocks Full Width Page
 *
*/
// Add Header Part
get_header();
the_post();
the_content();   
// Add Footer Part
get_footer();
?>