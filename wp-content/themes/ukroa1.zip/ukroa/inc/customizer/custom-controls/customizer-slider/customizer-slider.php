<?php
/**
 * Load Slider Customizer Controls
 */
require_once trailingslashit( dirname(__FILE__) ) . 'customizer-controls.php';